using System;

namespace MyAtas.Strategies
{
    // Utilidades de logging y throttling.
    public partial class FourSixEightSimpleStrategy
    {
        // (stub) Aquí centralizaremos: DebugLog wrappers y compuertas por barra/tick.
    }
}