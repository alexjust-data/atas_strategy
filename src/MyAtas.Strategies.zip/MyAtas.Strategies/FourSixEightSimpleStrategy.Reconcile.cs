using System;
using System.Collections.Generic;
using System.Linq;
using ATAS.Types;

namespace MyAtas.Strategies
{
    // Reconciliación de brackets (1x/bar) y asserts de integridad.
    public partial class FourSixEightSimpleStrategy
    {
        // (stub) Aquí moveremos: ReconcileBracketsWithNet, IntegrityCheckAfterMutation,
        // BuildAliveSnapshot, conteos activos y verificación de OCO/qty.
    }
}