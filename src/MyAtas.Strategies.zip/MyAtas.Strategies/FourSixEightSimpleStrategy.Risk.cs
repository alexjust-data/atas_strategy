using System;

namespace MyAtas.Strategies
{
    // Cálculos de riesgo y tamaño.
    public partial class FourSixEightSimpleStrategy
    {
        // (stub) Aquí moveremos: MoneyPerTick/TickValue mapping, ComputeRiskBasedQty,
        // Stop/TP en R, StopOffsetTicks, StopMinTicks, etc.
    }
}